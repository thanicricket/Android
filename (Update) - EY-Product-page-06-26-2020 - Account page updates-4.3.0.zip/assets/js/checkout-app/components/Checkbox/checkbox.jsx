import React, {Component} from 'react';

class Checkbox extends Component{
    constructor(props){
        super(props);      
    }


    render(){
        
        return (
        <div className="ship-complete">
        <label>
        <input type="checkbox" onChange={ this.props.onChange } 
        className={ this.props.className }/>
         Want your order to ship complete?
        </label>
        <span>This option may delay your order until all items are available to ship.</span>
        </div>
        )
    }
}

export default Checkbox;
