import React from 'react';
import styles from './section.scss';

export default class Section extends React.PureComponent {
    render() {
        return (
            <div className={ styles.section }>
                <div className={ styles.header }>
                    { this.props.header }
                </div>
		
		{this.props.data_show &&
			<div className={ styles.body }>
			    { this.props.body }
			</div>
		}

		{ this.props.edit_button_show && this.props.edit_data == true && this.props.customer_details!='' && 
		    <div className="stepHeader-actions stepHeader-column">
			<button className="button button--tertiary button--tiny optimizedCheckout-buttonSecondary" data-test="step-edit-button" type="button" onClick={this.props.edit_checkout_section}>Edit</button>
		    </div>
		}
		{ this.props.edit_button_show && this.props.data_shipping && 
		    <div className="stepHeader-actions stepHeader-column">
			<button className="button button--tertiary button--tiny optimizedCheckout-buttonSecondary" data-test="step-edit-button" type="button" onClick={this.props.edit_checkout_section}>Edit</button>
		    </div>
		}
            </div>
        );
    }
}
