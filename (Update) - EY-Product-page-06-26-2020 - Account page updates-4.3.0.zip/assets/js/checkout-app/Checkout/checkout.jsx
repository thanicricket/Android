import React, { Fragment } from 'react';
import { formatMoney } from 'accounting';
import { createCheckoutService } from '@bigcommerce/checkout-sdk';
import Panel from '../components/Panel/panel';
import SubmitButton from '../components/SubmitButton/submit-button';
import Billing from '../Billing/billing';
import Notes from '../Notes/notes';
import Po from '../Po/po';
import Cart from '../Cart/cart';
import Customer from '../Customer/customer';
import LoginPanel from '../LoginPanel/login-panel';
import Payment from '../Payment/payment';
import Shipping from '../Shipping/shipping';
import Layout from './Layout/layout';
import LoadingState from './LoadingState/loading-state';
import styles from './checkout.scss';

export default class Checkout extends React.PureComponent {
    constructor(props) {
        super(props);

        this.service = createCheckoutService();
        this.state = {
            isPlacingOrder: false,
            showSignInPanel: false,
            ship_complete_enabled: "none",
            POfieldvalue: "",
            ship_initial:1,
            PO_initial:1,
	    customer_section:true,
            shipping_section:false,
            billing_section:false,
            payment_section:false,
            edit_button_cutomer:false,
            edit_button_shipping:false,
            edit_button_billing:false
        };

        this.ChangeShippingCollect = this.ChangeShippingCollect.bind(this);
        this.ChangePONumber = this.ChangePONumber.bind(this);
        this.changeshippingOption = this.changeshippingOption.bind(this);
        this.shippingACRadioChange=this.shippingACRadioChange.bind(this);
        this.shippingACNumberChange=this.shippingACNumberChange.bind(this);
	this.toggle_login = this.toggle_login.bind(this);
    }

    componentDidMount() {
        Promise.all([
            this.service.loadCheckout(),
            this.service.loadShippingCountries(),
            this.service.loadShippingOptions(),
            this.service.loadBillingCountries(),
            this.service.loadPaymentMethods(),
        ]).then(() => {
            this.unsubscribe = this.service.subscribe((state) => {
                this.setState(state);
                let shipping_options=this.state.data.getShippingOptions();
                let selected_shipping_option=this.state.data.getSelectedShippingOption();

                if(typeof shipping_options !== "undefined"){
                    for(var i=0;i<shipping_options.length;i++){
                        if(shipping_options[i]["type"]=="fedex"){
                            this.setState({ "fedex_option":1 });
                        }
                        if(shipping_options[i]["type"]=="ups"){
                            this.setState({ "ups_option":1 });
                        }
                        if(shipping_options[i]["type"]!="ups"&&shipping_options[i]["type"]!="fedex"){
                            this.setState({ "other_option":1 });
                        }
                    }
                }
                if(this.state.ship_complete_enabled=="none"&&this.state.ship_initial==1){
                    let shipping_address=this.state.data.getShippingAddress();
                    let shipping_address_customFields=shipping_address.customFields;
                    let custom_Feilds=Array();
                    var j=0;
                    
                    for(var i=0;i<shipping_address_customFields.length;i++){
                        if(shipping_address_customFields[i]["fieldId"]!="field_25"){
                            custom_Feilds[j]=shipping_address_customFields[i];
                            j++;
                        }
                    }
                    shipping_address["customFields"]=custom_Feilds;
                    this.service.updateShippingAddress(shipping_address);
                    shipping_address=this.state.data.getShippingAddress();
                    this.setState({ "ship_initial":0 });
                }
                if(this.state.POfieldvalue==""&&this.state.PO_initial==1){
                    console.log("here i am");
                    let shipping_address=this.state.data.getShippingAddress();
                    let shipping_address_customFields=shipping_address.customFields;
                    let custom_Feilds=Array();
                    var j=0;
                    for(var i=0;i<shipping_address_customFields.length;i++){
                        if(shipping_address_customFields[i]["fieldId"]!="field_27"){
                            custom_Feilds[j]=shipping_address_customFields[i];
                            j++;
                        }
                    }                    
                    shipping_address["customFields"]=custom_Feilds;
                    this.service.updateShippingAddress(shipping_address);
                    shipping_address=this.state.data.getShippingAddress();
                    this.setState({ "PO_initial":0 });
                }
            });
        });
    }

    componentWillUnmount() {
        this.unsubscribe();
    }

    render() {
        const { data, errors, statuses } = this.state;

        if (!data) {
            return (
                <Layout body={
                    <LoadingState />
                } />
            );
        }

        if (this.state.showSignInPanel) {
            return (
                <Layout body={
                    <LoginPanel
                        errors={ errors.getSignInError() }
                        isSigningIn={ statuses.isSigningIn() }
                        onClick={ (customer) => this.service.signInCustomer(customer)
                            .then(() => this.service.loadShippingOptions())
                        }
                        onClose={ () => this.setState({ showSignInPanel: false }) } />
                } />
            );
        }

        return (
            <Layout body={
                <Fragment>
                    <div className={ styles.body }>
                        <Panel body={
                            <form onSubmit={ (event) => this._submitOrder(event, data.getCustomer().isGuest) } >
                                
                                { data.getCustomer().isGuest &&
                                    <h2 className="checkout-title">
                                    SECURE GUEST CHECKOUT
                                    </h2>
                                }
                                {!data.getCustomer().isGuest &&
                                    <h2 className="checkout-title">
                                    SECURE CHECKOUT
                                    </h2>
                                }
                                
                                <div className= 'checkout-customer'>
                                    <Customer
                                        customer={ data.getCustomer() }
                                        billingAddress={ data.getBillingAddress() }
                                        isSigningOut={ statuses.isSigningOut() }
                                        onClick={ () => this.service.signOutCustomer()
                                            .then(() => this.service.loadShippingOptions()) 
					    .then(() => this.onChange_toggle_customer())
					}
                                        onChange={ (customer) => this.setState({ customer }) }
                                        onSignIn={ () => this.setState({ showSignInPanel: true }) }
					data_show={this.state.customer_section}
                                        onChange_toggle_customer={ ()=> this.onChange_toggle_customer()}
					onChangeSign_out={ ()=> this.onChangeSign_out()}
                                        edit_button_cutomer={this.state.edit_button_cutomer}
                                        edit_customer_section = { ()=> this.edit_customer_section() }
					/>
                                </div>
                                <div className= 'checkout-shipping'>
                                    <Shipping
                                        customer={ data.getCustomer() }
                                        consignments={ data.getConsignments() }
                                        cart={ data.getCart() }
                                        isUpdatingConsignment={ statuses.isUpdatingConsignment }
                                        isCreatingConsignments={ statuses.isCreatingConsignments }
                                        isUpdatingShippingAddress={ statuses.isUpdatingShippingAddress }
                                        address={ data.getShippingAddress() }
                                        countries={ data.getShippingCountries() }
                                        options={ data.getShippingOptions() }
                                        selectedOptionId={ data.getSelectedShippingOption() ? data.getSelectedShippingOption().id : '' }
                                        isSelectingShippingOption ={ statuses.isSelectingShippingOption }
                                        onShippingOptionChange={ (optionId) => this.service.selectShippingOption(optionId) }
                                        onConsignmentUpdate={ (consignment) => (
                                            consignment.id ?
                                                this.service.updateConsignment(consignment) :
                                                this.service.createConsignments([consignment])
                                            )
                                        }
                                        onAddressChange={ (shippingAddress) => {
                                            this.setState({ shippingAddress })
                                            this.service.updateShippingAddress(shippingAddress)
                                        }}

                                        onChangeAccountNumber={ (e) => this.ChangeShippingCollect() }
                                        fedexOption= { this.state.fedex_option }
                                        upsOption= { this.state.ups_option }
                                        otherOption= { this.state.other_option }

                                        onChangeShippingOption={ (e)=> this.changeshippingOption() }
                                       
                                        onshippingACRadioChange={(e)=>this.shippingACRadioChange() }

                                        onshippingACNumberChange={(e)=>this.shippingACNumberChange() }

					data_show={this.state.shipping_section}
                                        onChange_toggle_shipping={ ()=> this.onChange_toggle_shipping(this.state.billing_address_same_as_shipping_check)}
                                        edit_button_shipping={this.state.edit_button_shipping}
                                        edit_shipping_section = { ()=> this.edit_shipping_section() }

                                    />
                                </div>                                
                                <div className= 'checkout-payment'>
                                    <Payment
                                        errors={ errors.getSubmitOrderError() }
                                        methods={ data.getPaymentMethods() }
                                        onClick={ (name, gateway) => this.service.initializePayment({ methodId: name, gatewayId: gateway }) }
                                        onChange={ (payment) => this.setState({ payment }) }
					data_show={this.state.billing_section}
					/>
                                
                                    <div className= 'checkout-billing'>
                                        <Billing
                                            multishipping={ (data.getConsignments() || []).length > 1 }
                                            address={ data.getBillingAddress() }
                                            countries={ data.getBillingCountries() }
                                            sameAsShippingAddress={
                                                (this.state.billingAddressSameAsShippingAddress === undefined) ||
                                                this.state.billingAddressSameAsShippingAddress
                                            }
                                            onChange ={ (billingAddress) => this.setState({ billingAddress }) }
                                            onSelect ={ (billingAddressSameAsShippingAddress) => this.setState({ billingAddressSameAsShippingAddress })  } 
					    data_show={this.state.billing_section}
					    />
                                    </div>
				    { this.state.billing_section && 
					    <div className="checkout-po-section">
						<Po
						onChange={ (PoValue) => this.setState({ PoValue }) }
						onChangePONumber={ (e) => this.ChangePONumber() }
						 />
					    </div>
				   }
                                </div>
				 { this.state.billing_section &&
                                <div className= 'checkout-notes'>
                                    <Notes
                                        onChange={ (customerMessage) => this.setState({ customerMessage }) } />
                                </div>
				}
				{ this.state.billing_section &&
                                <div className= 'terms-condition'>
                                    <div className="terms-section">
                                        <div className="terms-checkbox">
                                            <label className="checkbox-container">
                                            <input type="checkbox" required/>
                                            <span className="checkmark"></span>
                                            </label>
                                        </div>
                                        <div className="terms-content">
                                            <h4>Terms and conditions</h4>
                                            By checking this box, I verify that I have read & I accept SkyGeek.com's <a href="terms-conditions">Terms & Conditions</a>
                                        </div>
                                    </div>
                                </div>
				}
				{ this.state.billing_section &&
                                <div className={ styles.actionContainer }>
                                    <SubmitButton
                                        label={ this._isPlacingOrder() ?
                                            'Placing your order...' :
                                            `COMPLETE YOUR ORDER`
                                        }
                                        isLoading={ this._isPlacingOrder() } />
                                     <button className="save-your-quote">SAVE YOUR QUOTE</button>
                                     <div className="back-to-cart">
                                        <a href="cart.php">Back To Cart</a>
                                    </div>
                                </div>
				}
                               
                            </form>

                        } />
                    </div>

                    <div className={ styles.side }>
                        <Cart
                            checkout={ data.getCheckout() }
                            cartLink={ (data.getConfig()).links.cartLink } />
                    </div>
                </Fragment>
            } />
        );
    }



     //Toggle the Signin Section When Guset User Clicks Multi Shipping
    toggle_login(){
        this.setState( ()=> ({showSignInPanel:true}));
        window.scrollTo(0, 0);
        this.setState ({customer_section:true,shipping_section:false,billing_section:false,payment_section:false,edit_button_cutomer:false,edit_button_shipping:false,edit_button_billing:false});
	}
    
    //Toggle components
    //edit button customer component
    edit_customer_section(){
        //.log("edit_customer_section");
        this.setState ({edit_button_cutomer:false,edit_button_shipping:false,edit_button_billing:false,customer_section:true,shipping_section:false,billing_section:false,payment_section:false});
    }

    //edit button shipping component
    edit_shipping_section(){
        //////console.log("edit_shipping_section");
        this.setState ({edit_button_shipping:false,edit_button_billing:false,customer_section:false,shipping_section:true,billing_section:false,payment_section:false});
    }

    //edit button billing component
    edit_billing_section(){
        //////console.log("edit_billing_section");
        this.setState ({edit_button_shipping:true,edit_button_billing:false,customer_section:false,shipping_section:false,billing_section:true,payment_section:false});
    }

    //When click sign out button, hidden all edit button and components otherthan customer component
    onChangeSign_out(){
        //////console.log("onChangeSign_out");
        this.setState ({customer_section:true,shipping_section:false,billing_section:false,payment_section:false,edit_button_cutomer:false,edit_button_shipping:false,edit_button_billing:false});
    }
    
    //customer section continue to open shipping section (its also use in after login user directly open vshipping section)
    onChange_toggle_customer(){
        //.log("onChange_toggle_customer");
        this.setState ({edit_button_cutomer:true,edit_button_shipping:false,edit_button_billing:false,customer_section:false,shipping_section:true,billing_section:false,payment_section:false});
    }

    //shipping section continue to open billing section
    onChange_toggle_shipping(is_checked){
        if(!is_checked){
            this.setState ({edit_button_cutomer:true,edit_button_shipping:true,edit_button_billing:false,customer_section:false,shipping_section:false,billing_section:true,payment_section:false});
        }else{
            this.setState ({edit_button_cutomer:true,edit_button_shipping:true,edit_button_billing:true,customer_section:false,shipping_section:false,billing_section:false,payment_section:true});
        }
    }

    //billing section continue to open payment section
    onChange_toggle_billing(){
       // ////console.log("onChange_toggle_billing");
        this.setState ({edit_button_cutomer:true,edit_button_shipping:true,edit_button_billing:true,customer_section:false,shipping_section:false,billing_section:false,payment_section:true});
    }
    //Toggle components


    shippingACNumberChange(){

        let shipping_address=this.state.data.getShippingAddress();
        let customFields_array=shipping_address.customFields;
        
        console.log(customFields_array);
        console.log("Checking");

        let Accnumber=$(".shipping-account-input #shippingAccountNO").val();
        
        var field_30=0;

        if(customFields_array.length>0){
            for(var i=0;i<customFields_array.length;i++){
                if(customFields_array[i]["fieldId"]=="field_30"){
                    field_30=i;
                }
            }

            if(field_30>0){
                customFields_array[field_30]={
                  "fieldId": "field_30",
                  "fieldValue": Accnumber
                };
            }else{
                customFields_array[customFields_array.length]={
                  "fieldId": "field_30",
                  "fieldValue": Accnumber
                };
            }

            shipping_address["customFields"]=customFields_array;
            this.service.updateShippingAddress(shipping_address);

        }else{
            customFields_array[0]={
              "fieldId": "field_30",
              "fieldValue": Accnumber
            };
            
            shipping_address["customFields"]=customFields_array;
            this.service.updateShippingAddress(shipping_address);
        }
                
        shipping_address=this.state.data.getShippingAddress();
        console.log(shipping_address);
    }

    shippingACRadioChange(){
        $(".shipping-account-input").css("display","block");
    }

    changeshippingOption(){
        var selected=$("input[name=shippingOption]:checked").val();
        if(selected==1){
            $(".optionContainer").removeClass("show-option");
            $(".optionContainer").addClass("hide-option");            
            $(".fedex-options").addClass("show-option");
            $(".fedex-options").removeClass("hide-option");
        }else if(selected==2){
            $(".optionContainer").removeClass("show-option");
            $(".optionContainer").addClass("hide-option");            
            $(".ups-options").addClass("show-option");
            $(".ups-options").removeClass("hide-option");
        }else if(selected==3){
            $(".optionContainer").removeClass("show-option");
            $(".optionContainer").addClass("hide-option");            
            $(".other-options").addClass("show-option");
            $(".other-options").removeClass("hide-option");
        }
    }

    ChangePONumber(){
        console.log("PO changing");
        let shipping_address=this.state.data.getShippingAddress();
        //shipping_address["customFields"]=Array();
        //this.service.updateShippingAddress(shipping_address);

        let customFields_array=shipping_address.customFields;
        let ponumber=$("#pofield").val();
        this.setState({ "POfieldvalue":1 });

        var field_27=0;

        if(customFields_array.length>0){
            for(var i=0;i<customFields_array.length;i++){
                if(customFields_array[i]["fieldId"]=="field_27"){
                    field_27=i;
                }
            }

            if(field_27>0){
                customFields_array[field_27]={
                  "fieldId": "field_27",
                  "fieldValue": ponumber
                };
            }else{
                customFields_array[customFields_array.length]={
                  "fieldId": "field_27",
                  "fieldValue": ponumber
                };
            }

            shipping_address["customFields"]=customFields_array;
            this.service.updateShippingAddress(shipping_address);

        }else{
            customFields_array[0]={
              "fieldId": "field_27",
              "fieldValue": ponumber
            };
            shipping_address["customFields"]=customFields_array;
            this.service.updateShippingAddress(shipping_address);
        }
                
        shipping_address=this.state.data.getShippingAddress();
        console.log(shipping_address);
    }

    ChangeShippingCollect(data){
        let shipping_address=this.state.data.getShippingAddress();
        let customFields_array=shipping_address.customFields;
        var field_25=-1;

        if(customFields_array.length>0){
            for(var i=0;i<customFields_array.length;i++){
                if(customFields_array[i]["fieldId"]=="field_25"){
                    field_25=i;
                }
            }

            if(field_25>0){
                if($(".ship-complete-field").is(":checked")==true){
                    customFields_array[field_25]={
                      "fieldId": "field_25",
                      "fieldValue": "SHIP COMPLETE"
                    };
                    this.setState({ ship_complete_enabled: true });
                }else{
                    customFields_array[field_25]={
                      "fieldId": "field_25",
                      "fieldValue": ""
                    };
                    this.setState({ ship_complete_enabled: false });
                }
            }else{
                if(field_25==-1){
                    if($(".ship-complete-field").is(":checked")==true){
                        customFields_array[customFields_array.length]={
                          "fieldId": "field_25",
                          "fieldValue": "SHIP COMPLETE"
                        };
                        this.setState({ ship_complete_enabled: true });
                    }else{
                        customFields_array[customFields_array.length]={
                          "fieldId": "field_25",
                          "fieldValue": ""
                        };
                        this.setState({ ship_complete_enabled: false });
                    }
                }else{
                    if($(".ship-complete-field").is(":checked")==true){
                        customFields_array[0]={
                          "fieldId": "field_25",
                          "fieldValue": "SHIP COMPLETE"
                        };
                        this.setState({ ship_complete_enabled: true });
                    }else{
                        customFields_array[0]={
                          "fieldId": "field_25",
                          "fieldValue": ""
                        };
                        this.setState({ ship_complete_enabled: false });
                    }
                }
            }

            shipping_address["customFields"]=customFields_array;
            this.service.updateShippingAddress(shipping_address);

        }else{
            if($(".ship-complete-field").is(":checked")==true){
                customFields_array[0]={
                  "fieldId": "field_25",
                  "fieldValue": "SHIP COMPLETE"
                };
                this.setState({ ship_complete_enabled: true });
            }else{
                customFields_array[0]={
                  "fieldId": "field_25",
                  "fieldValue": ""
                };
                this.setState({ ship_complete_enabled: false });
            }
            shipping_address["customFields"]=customFields_array;
            this.service.updateShippingAddress(shipping_address);
        }

        
        shipping_address=this.state.data.getShippingAddress();
        console.log(shipping_address);
    }

    _isPlacingOrder() {
        const { statuses } = this.state;
        return this.state.isPlacingOrder && (
            statuses.isSigningIn() ||
            statuses.isUpdatingShippingAddress() ||
            statuses.isUpdatingBillingAddress() ||
            statuses.isSubmittingOrder()
        );
    }

    _submitOrder(event, isGuest) {
        let billingAddressPayload = this.state.billingAddressSameAsShippingAddress ?
            this.state.shippingAddress :
            this.state.billingAddress;

        let customerNotesPayload = this.state.customerMessage;
        billingAddressPayload = { ...billingAddressPayload, email: this.state.customer.email };
        let { payment } = this.state;

        this.setState({ isPlacingOrder: true });
        event.preventDefault();

        Promise.all([
            isGuest ? this.service.continueAsGuest(this.state.customer) : Promise.resolve(),
            this.service.updateBillingAddress(billingAddressPayload),
            this.service.updateCheckout(customerNotesPayload),
        ])
            .then(() => this.service.submitOrder({ payment }))
            .then(({ data }) => {
                window.location.href = data.getConfig().links.orderConfirmationLink;
            })
            .catch(() => this.setState({ isPlacingOrder: false }));
    }
}
