import React from 'react';
import ReactDOM from 'react-dom';
import Checkout from './Checkout/checkout';

ReactDOM.render(<Checkout />, document.getElementById('checkout-app'));
