import React, { Fragment } from 'react';
import { formatMoney } from 'accounting';
import EmptyState from './EmptyState/empty-state';
import RadioContainer from '../components/RadioContainer/radio-container';
import RadioInput from '../components/RadioInput/radio-input';

export default class ShippingOptions extends React.PureComponent {
    constructor(props) {
        super(props);

        console.log(props);
    }

    render() {
        return (
            <RadioContainer
                label={ 'Shipping Option' }
                body={
                    <Fragment>
                        { this.props.isUpdatingShippingAddress &&
                            <EmptyState
                                body={ 'Loading shipping options...' }
                                isLoading={ true } />
                        }
                        {
                            !this.props.isUpdatingShippingAddress &&
                            (!this.props.options || !this.props.options.length) &&
                            <EmptyState
                                body={ 'Sorry, there is no available shipping option.' }
                                isLoading={ false } />
                        }
                        { this.props.fedexOption == 1 &&
                    
                                <div className="fedexContainer shippingContainer">
                                    <RadioInput
                                        name={ 'shippingOption' }
                                        checked={ this.props.selectedOption === "fedex" }
                                        label={ `Fedex` }
                                        value= { '1' }
                                        onClick={ () => this.props.onChangeShippingOption() }
                                        />
                                    <div className="fedex-options optionContainer">
                                    {
                                        !this.props.isUpdatingShippingAddress &&
                                        this.props.options && this.props.options.length && (this.props.options).map(option => option.type == "fedex" ? (
                                        <RadioInput
                                            key={ option.id }
                                            name={ 'shippingOption' + this.props.consignmentId }
                                            value={ option.id }
                                            checked={ this.props.selectedOptionId === option.id }
                                            label={ `${ option.description } - ${ formatMoney(option.cost) }` }
                                            isLoading={ this.props.isSelectingShippingOption || this.props.isUpdatingShippingAddress }
                                            onChange={ () => this.props.onSelect(option.id) } />
                                        ) : (
                                            ""
                                        )
                                    )}
                                    </div>
                                </div>
                                }

                                { this.props.upsOption == 1 &&
                                <div className="upsContainer shippingContainer">
                                    <RadioInput
                                        name={ 'shippingOption' }
                                        label={ `UPS` }
                                        value= { '2' }
                                        onChange={ () => this.props.onChangeShippingOption() }
                                        />
                                    <div className="ups-options optionContainer">
                                    {    
                                        !this.props.isUpdatingShippingAddress &&
                                        this.props.options && this.props.options.length && (this.props.options).map(option => option.type == "ups" ? (
                                        <RadioInput
                                            key={ option.id }
                                            name={ 'shippingOption' + this.props.consignmentId }
                                            value={ option.id }
                                            checked={ this.props.selectedOptionId === option.id }
                                            label={ `${ option.description } - ${ formatMoney(option.cost) }` }
                                            isLoading={ this.props.isSelectingShippingOption || this.props.isUpdatingShippingAddress }
                                            onChange={ () => this.props.onSelect(option.id) } />
                                        ) : (
                                            ""
                                        )
                                    )}
                                    </div>
                                </div>
                                }
                                { this.props.otherOption == 1 &&
                                <div className="otherContainer shippingContainer">
                                    <RadioInput
                                        name={ 'shippingOption' }
                                        
                                        label={ `Other` }
                                        value= { '3' }
                                        onChange={ () => this.props.onChangeShippingOption() }
                                        />
                                    <div className="other-options optionContainer">
                                    {
                                        !this.props.isUpdatingShippingAddress &&
                                        this.props.options && this.props.options.length && (this.props.options).map(option => (option.type !== "fedex" && option.type !== "ups" ) ? (
                                        <RadioInput
                                            key={ option.id }
                                            name={ 'shippingOption' + this.props.consignmentId }
                                            value={ option.id }
                                            checked={ this.props.selectedOptionId === option.id }
                                            label={ `${ option.description } - ${ formatMoney(option.cost) }` }
                                            isLoading={ this.props.isSelectingShippingOption || this.props.isUpdatingShippingAddress }
                                            onChange={ () => this.props.onSelect(option.id) } />
                                        ) : (
                                            ""
                                        )
                                    )}
                                    </div>
                                </div>  
                        }
                    </Fragment>
                } />
            );
        }
    }
