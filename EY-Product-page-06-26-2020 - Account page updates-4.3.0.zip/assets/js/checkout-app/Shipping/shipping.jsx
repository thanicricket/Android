import React, { Fragment } from 'react';
import { find } from 'lodash';
import Section from '../components/Section/section';
import ShippingToggle from './shipping-toggle';
import SingleShipping from './single-shipping'
import MultiShipping from './multi-shipping'

export default class Shipping extends React.PureComponent {
    constructor(props) {
        super(props);
        console.log(props);
        var ship_complete="";
        if(typeof props.address.customFields != "undefined"){
            var customfields=props.address.customFields;
            for(var i=0;i<customfields.length;i++){
                if(customfields[i]["fieldId"]=="field_25"){
                    ship_complete=customfields[i]["fieldValue"];
                }
            }
        }

        let shipping_options=props.options;
        let fedex_option;
        let ups_option;
        let other_option;
        if(typeof shipping_options !== "undefined"){
            if(shipping_options.length<=0){
                fedex_option=1;
                ups_option=1;
                other_option=1;
            }else{
                fedex_option=0;
                ups_option=0;
                other_option=0;
            }
        }
        let selected_option="fedex";
        if(typeof shipping_options !== "undefined"){
            for(var i=0;i<shipping_options.length;i++){
                if(shipping_options[i]["type"]=="fedex"){
                    fedex_option=1;
                    if(this.props.selectedOptionId == shipping_options[i]["id"]){
                        selected_option="fedex";
                    }
                }
                if(shipping_options[i]["type"]=="ups"){
                    ups_option=1;
                    if(this.props.selectedOptionId == shipping_options[i]["id"]){
                        selected_option="ups";
                    }
                }
                if(shipping_options[i]["type"]!="ups"&&shipping_options[i]["type"]!="fedex"){
                    other_option=1;
                    if(this.props.selectedOptionId == shipping_options[i]["id"]){
                        selected_option="fedex";
                    }
                }
            }
        }

        this.state = {
            multiShipping: (this.props.consignments || []).length > 1,
            ship_complete:ship_complete,
            fedex_option:fedex_option,
            ups_option:ups_option,
            other_option:other_option,
        };
        
        
    }

    render() {
        return (
            <Section header={ 'Shipping' } body={
                <Fragment>
                    {
                        this._hasSavedAddresses() &&
                        this._hasMultiplePhysicalItems() &&
                        <ShippingToggle
                            onChange={ (value) => this._toggleMultiShipping(value) }
                            multiShipping={ this.state.multiShipping } />
                    }
                    {
                        this.state.multiShipping ?
                        <MultiShipping
                            customer={ this.props.customer }
                            consignments={ this.props.consignments }
                            cart={ this.props.cart }
                            isUpdatingConsignment={ this.props.isUpdatingConsignment }
                            isCreatingConsignments={ this.props.isCreatingConsignments }
                            isSelectingShippingOption={ this.props.isSelectingShippingOption }
                            cart={ this.props.cart }
                            onConsignmentUpdate={ this.props.onConsignmentUpdate }

                            fedexOption= { this.props.fedexOption }
                            upsOption= { this.props.upsOption }
                            otherOption= { this.props.otherOption }
                        /> :
                        <SingleShipping
                            countries={ this.props.countries }
                            address={ this.props.address }
                            onAddressChange={ this.props.onAddressChange }
                            selectedOptionId={ this.props.selectedOptionId }
                            options={ this.props.options }
                            isUpdatingShippingAddress={ this.props.isUpdatingShippingAddress }
                            isSelectingShippingOption={ this.props.isSelectingShippingOption }
                            onSelect={ this.props.onShippingOptionChange }
                            onChangeAccountNumber= {this.props.onChangeAccountNumber }
                            ship_complete= { this.state.ship_complete }
                            onChangeShippingOption={this.props.onChangeShippingOption }
                            fedexOption= { this.state.fedex_option }
                            upsOption= { this.state.ups_option }
                            otherOption= { this.state.other_option }
                            selectedOption={ this.state.selected_option }
                            
                            onshippingACRadioChange={this.props.onshippingACRadioChange }

                            onshippingACNumberChange={this.props.onshippingACNumberChange } 

                        />
                    }
                </Fragment>
            } />
        );
    }

    _toggleMultiShipping(multiShipping) {
        this.setState({ multiShipping });
    }

    _hasSavedAddresses() {
        return this.props.customer.addresses &&
            this.props.customer.addresses.length > 1;
    }

    _hasMultiplePhysicalItems() {
        return this.props.cart.lineItems.physicalItems.length > 1;
    }
}
