    import PageManager from './page-manager';
import _ from 'lodash';
import giftCertCheck from './common/gift-certificate-validator';
import utils from '@bigcommerce/stencil-utils';
import ShippingEstimator from './cart/shipping-estimator';
import { defaultModal } from './global/modal';
import swal from './global/sweet-alert';

export default class Cart extends PageManager {
    onReady() {
        this.$cartContent = $('[data-cart-content]');
        this.$cartMessages = $('[data-cart-status]');
        this.$cartTotals = $('[data-cart-totals]');
        this.$overlay = $('[data-cart] .loadingOverlay')
            .hide(); // TODO: temporary until roper pulls in his cart components

        this.bindEvents();

        function calcTimeDetail(city, offset) {
            var d = new Date();
            var utc = d.getTime() + (d.getTimezoneOffset() * 60000);
            var nd = new Date(utc + (3600000*offset));
            return nd;
        }    
        var reload_needed = this;
        $("#overlay-container").css("display","block");
        var est_time_detail = calcTimeDetail('EST', '-4');
        var current_est_time = est_time_detail.getHours();
        var current_est_day = est_time_detail.getDay();

        fetch('/api/storefront/cart?include=lineItems.physicalItems.options', {
            credentials: 'include'
        }).then(function (response) {
            return response.json();
        }).then(function (cartJson) {
            //console.log(cartJson[0]);
            if(typeof cartJson[0] !== "undefined"){
                var physicalItems=cartJson[0]["lineItems"]["physicalItems"];
                var shipping_addon_not_exist=0;
                var shipping_addon_exist = 0;
                if(physicalItems.length > 0){
                    $("#overlay-container").css("display","block");        
                }

                for (var i = 0; i < physicalItems.length; i++) {
                    if(physicalItems[i].sku == "MFG-CERT" && physicalItems[i]["options"].length<=0){
                        utils.api.cart.itemRemove(physicalItems[i]["id"], (err, response) => {
                        });                      
                    }

                    if(physicalItems[i].sku == "HAZMAT-FEE" && physicalItems[i]["options"].length<=0){
                        utils.api.cart.itemRemove(physicalItems[i]["id"], (err, response) => {
                        });                      
                    }

                    if(physicalItems[i].sku == "Same Day Ship Guarantee Product ID"){
                        // Hide same day shipping option if the current EST time crosses 3pm or the current day is Saturday or Sunday
                        if(current_est_time >= 15 || current_est_day == 0 || current_est_day == 6){
                            utils.api.cart.itemRemove(physicalItems[i]["id"], (err, response) => {
                                if (response.data.status === 'succeed') {
                                    reload_needed.refreshContent(true);
                                    $("#overlay-container").css("display","none");
                                }
                            });
                            shipping_addon_exist = 1;
                        }
                    }else{
                        shipping_addon_not_exist = 1;
                    }

                    if(physicalItems[i].sku == "Same Day Ship Guarantee Product ID" && physicalItems[i]["options"].length<=0){
                        utils.api.cart.itemRemove(physicalItems[i]["id"], (err, response) => {
                        });                      
                    }
                }

                if(shipping_addon_not_exist == 1 && shipping_addon_exist == 0){
                    $("#overlay-container").css("display","none");
                }
                reload_needed.$overlay.hide();
            
                return cartJson[0].id;
            }else{
                reload_needed.$overlay.hide();
                $("#overlay-container").css("display","none");
            }

        }).catch(function (error) {
            $("#overlay-container").css("display","none");
            console.log(error);
        }).then(function (cartId) {
            
        });
    }

    cartUpdate($target) {

        const itemId = $target.data('cartItemid');
        const $el = $(`#qty-${itemId}`);
        const oldQty = parseInt($el.val(), 10);
        const maxQty = parseInt($el.data('quantityMax'), 10);
        const minQty = parseInt($el.data('quantityMin'), 10);
        const minError = $el.data('quantityMinError');
        const maxError = $el.data('quantityMaxError');
        const newQty = $target.data('action') === 'inc' ? oldQty + 1 : oldQty - 1;

        // Does not quality for min/max quantity
        if (newQty < minQty) {
            return swal({
                text: minError,
                type: 'error',
            });
        } else if (maxQty > 0 && newQty > maxQty) {
            return swal({
                text: maxError,
                type: 'error',
            });
        }

        this.$overlay.show();
        utils.api.cart.itemUpdate(itemId, newQty, (err, response) => {
            
            if (response.data.status === 'succeed') {
                const parentSKU=$el.data("sku");
                if(typeof $("body #"+parentSKU).find(".cart-item-qty-input") !== "undefined"){
                    const faaId=$("body #"+parentSKU).find(".cart-item-qty-input").attr("data-cart-itemid");
                    utils.api.cart.itemUpdate(faaId, newQty, (err, response) => {
                        this.$overlay.hide();
                        const remove = (newQty === 0);
                        this.refreshContent(remove);
                    });  
                }else{
                    this.$overlay.hide();
                    const remove = (newQty === 0);
                    this.refreshContent(remove);
                }
                  
                // if the quantity is changed "1" from "0", we have to remove the row.
                $("body .part-number-sku").each(function(){
                    var part_class=$(this).text();
                    part_class=part_class.trim();
                    if($("body  ."+part_class).find(".part-class").length<=0){
                       $("body ."+part_class).append("<span class='part-class'>Part #: "+part_class+"</span>");
                    }
                });
            } else {
                $el.val(oldQty);
                swal({
                    text: response.data.errors.join('\n'),
                    type: 'error',
                });
            }
        });
    }

    cartUpdateQtyTextChange($target, preVal = null) {
        const itemId = $target.data('cartItemid');
        const $el = $(`#qty-${itemId}`);
        const maxQty = parseInt($el.data('quantityMax'), 10);
        const minQty = parseInt($el.data('quantityMin'), 10);
        const oldQty = preVal !== null ? preVal : minQty;
        const minError = $el.data('quantityMinError');
        const maxError = $el.data('quantityMaxError');
        const newQty = parseInt(Number($el.val()), 10);
        let invalidEntry;

        // Does not quality for min/max quantity
        if (!newQty) {
            invalidEntry = $el.val();
            $el.val(oldQty);
            return swal({
                text: `${invalidEntry} is not a valid entry`,
                type: 'error',
            });
        } else if (newQty < minQty) {
            $el.val(oldQty);
            return swal({
                text: minError,
                type: 'error',
            });
        } else if (maxQty > 0 && newQty > maxQty) {
            $el.val(oldQty);
            return swal({
                text: maxError,
                type: 'error',
            });
        }

        this.$overlay.show();
        
        utils.api.cart.itemUpdate(itemId, newQty, (err, response) => {
            //this.$overlay.hide();

            if (response.data.status === 'succeed') {
                // if the quantity is changed "1" from "0", we have to remove the row.
                const parentSKU=$el.data("sku");
                
                if(parentSKU == "FAA-8130-3"){
                    var parent_sku=$("[data-sku=FAA-8130-3]").parents(".cart-item-quantity").attr("id");
                    fetch('/api/storefront/cart?include=lineItems.physicalItems.options', {
                        credentials: 'include'
                    }).then(function (response) {
                        return response.json();
                    }).then(function (cartJson) {
                        var physicalItems=cartJson[0]["lineItems"]["physicalItems"];
                        for (var i = 0; i < physicalItems.length; i++) {
                            //console.log(physicalItems[i]);
                            if(physicalItems[i]["sku"] == parent_sku){
                                var update_id= physicalItems[i]["id"];
                                utils.api.cart.itemUpdate(update_id, newQty, (err, response) => {
                                    location.reload();
                                    //$('[data-cart] .loadingOverlay').hide();
                                                                        
                                    //this.overlayReload(newQty);
                                });

                            }
                        }
                    });
                   
                }else{
                    if(typeof $("body #"+parentSKU).find(".cart-item-qty-input") !== "undefined"){
                        const faaId=$("body #"+parentSKU).find(".cart-item-qty-input").attr("data-cart-itemid");
                        utils.api.cart.itemUpdate(faaId, newQty, (err, response) => {
                            this.$overlay.hide();
                            const remove = (newQty === 0);
                            this.refreshContent(remove);
                        }); 
                    }else{
                        this.$overlay.hide();
                        const remove = (newQty === 0);
                        this.refreshContent(remove);
                    }
                }

                //const remove = (newQty === 0);
                //this.refreshContent(remove);

                $("body .part-number-sku").each(function(){
                    var part_class=$(this).text();
                    part_class=part_class.trim();
                    if($("body  ."+part_class).find(".part-class").length<=0){
                       $("body ."+part_class).append("<span class='part-class'>Part #: "+part_class+"</span>");
                    }
                });
            } else {
                $el.val(oldQty);
                swal({
                    text: response.data.errors.join('\n'),
                    type: 'error',
                });
            }
        });
    }

    
    cartRemoveItem(itemId) {
        this.$overlay.show();
        utils.api.cart.itemRemove(itemId, (err, response) => {
            if (response.data.status === 'succeed') {
                this.refreshContent(true);
            } else {
                swal({
                    text: response.data.errors.join('\n'),
                    type: 'error',
                });
            }
        });
    }
    cartRefreshContent(){
        this.refreshContent();
    }
    cartEditOptions(itemId) {
        const modal = defaultModal();
        const options = {
            template: 'cart/modals/configure-product',
        };

        modal.open();
        utils.api.productAttributes.configureInCart(itemId, options, (err, response) => {
            modal.updateContent(response.content);
            this.bindGiftWrappingForm();
        });

        utils.hooks.on('product-option-change', (event, option) => {
            const $changedOption = $(option);
            const $form = $changedOption.parents('form');
            const $submit = $('input.button', $form);
            const $messageBox = $('.alertMessageBox');
            const item = $('[name="item_id"]', $form).attr('value');

            utils.api.productAttributes.optionChange(item, $form.serialize(), (err, result) => {
                const data = result.data || {};

                if (err) {
                    swal({
                        text: err,
                        type: 'error',
                    });
                    return false;
                }

                if (data.purchasing_message) {
                    $('p.alertBox-message', $messageBox).text(data.purchasing_message);
                    $submit.prop('disabled', true);
                    $messageBox.show();
                } else {
                    $submit.prop('disabled', false);
                    $messageBox.hide();
                }

                if (!data.purchasable || !data.instock) {
                    $submit.prop('disabled', true);
                } else {
                    $submit.prop('disabled', false);
                }
            });
        });
    }

    refreshContent(remove) {
        const $cartItemsRows = $('[data-item-row]', this.$cartContent);
        const $cartPageTitle = $('[data-cart-page-title]');
        const options = {
            template: {
                content: 'cart/content',
                totals: 'cart/totals',
                pageTitle: 'cart/page-title',
                statusMessages: 'cart/status-messages',
            },
        };

        this.$overlay.show();

        // Remove last item from cart? Reload
        if (remove && $cartItemsRows.length === 1) {
            return window.location.reload();
        }

        utils.api.cart.getContent(options, (err, response) => {
            this.$cartContent.html(response.content);
            this.$cartTotals.html(response.totals);
            this.$cartMessages.html(response.statusMessages);

            $cartPageTitle.replaceWith(response.pageTitle);
            this.bindEvents();
            this.$overlay.hide();

            const quantity = $('[data-cart-quantity]', this.$cartContent).data('cartQuantity') || 0;
            $('body').trigger('cart-quantity-update', quantity);

            $("body .part-number-sku").each(function(){
                var part_class=$(this).text();
                part_class=part_class.trim();
                if($("body  ."+part_class).find(".part-class").length<=0){
                   $("body ."+part_class).append("<span class='part-class'>Part #: "+part_class+"</span>");
                }
            });
        });
    }

    bindCartEvents() {
        const debounceTimeout = 400;
        const cartUpdate = _.bind(_.debounce(this.cartUpdate, debounceTimeout), this);
        const cartUpdateQtyTextChange = _.bind(_.debounce(this.cartUpdateQtyTextChange, debounceTimeout), this);
        const cartRemoveItem = _.bind(_.debounce(this.cartRemoveItem, debounceTimeout), this);
        let preVal;

        // cart update
        $('[data-cart-update]', this.$cartContent).on('click', event => {
            const $target = $(event.currentTarget);
            event.preventDefault();
            // update cart quantity
            cartUpdate($target);
        });

        // cart qty manually updates
        $('.cart-item-qty-input', this.$cartContent).on('focus', function onQtyFocus() {
            preVal = this.value;
        }).change(event => {
            const $target = $(event.currentTarget);
            event.preventDefault();
            // update cart quantity
            cartUpdateQtyTextChange($target, preVal);
        });

        $('.cart-remove', this.$cartContent).on('click', event => {
            const itemId = $(event.currentTarget).data('cartItemid');
            const string = $(event.currentTarget).data('confirmDelete');
            
            swal({
                text: string,
                type: 'warning',
                showCancelButton: true,
            }).then(() => {

                fetch('/api/storefront/cart?include=lineItems.physicalItems.options', {
                    credentials: 'include'
                }).then(function (response) {
                    return response.json();
                }).then(function (cartJson) {
                    var physicalItems=cartJson[0]["lineItems"]["physicalItems"];
                    var certificate_added=0; 
                    var remove_manufature_fee;
                    var remove_sameday_ship;
                    var remove_faa_form; 
                    var remove_hazmat_fee;
                    var timeout=0;
                    for (var i = 0; i < physicalItems.length; i++) {
                        if(itemId == physicalItems[i]["id"]){
                            var product_line_name=physicalItems[i]["name"];
                        }
                    }

                    for (var i = 0; i < physicalItems.length; i++) {
                        /*Manufacturer Certificate*/
                        if(physicalItems[i].productId == 132 && physicalItems[i]["options"].length>0){
                            if(physicalItems[i]["options"][0]["name"]=="Add on for"){
                                if(physicalItems[i]["options"][0]["value"]==product_line_name){
                                    remove_manufature_fee=physicalItems[i]["id"];
                                    timeout=timeout+800;
                                    setTimeout(function(){ 
                                        utils.api.cart.itemRemove(remove_manufature_fee, (err, response) => {
                                            
                                        });
                                    },timeout);
                                }
                            }
                        }
                        /*Same day ship*/
                        if(physicalItems[i].productId == 165 && physicalItems[i]["options"].length>0){
                            if(physicalItems[i]["options"][0]["name"]=="Add on for"){
                                if(physicalItems[i]["options"][0]["value"]==product_line_name){
                                    remove_sameday_ship=physicalItems[i]["id"];
                                    timeout=timeout+800;
                                    setTimeout(function(){ 
                                        utils.api.cart.itemRemove(remove_sameday_ship, (err, response) => {
                                            
                                        });
                                    },timeout);
                                }
                            }
                        }

                        /*FAA form*/
                        if(physicalItems[i].productId == 166 && physicalItems[i]["options"].length>0){
                            if(physicalItems[i]["options"][0]["name"]=="Add on for"){
                                if(physicalItems[i]["options"][0]["value"]==product_line_name){
                                    remove_faa_form=physicalItems[i]["id"];
                                    timeout=timeout+800;
                                    setTimeout(function(){ 
                                        utils.api.cart.itemRemove(remove_faa_form, (err, response) => {
                                            
                                        });
                                    },timeout);
                                }
                            }
                        }

                        if(physicalItems[i].productId == 167 && physicalItems[i]["options"].length>0){
                            if(physicalItems[i]["options"][0]["name"]=="Add on for"){
                                if(physicalItems[i]["options"][0]["value"]==product_line_name){
                                    remove_hazmat_fee=physicalItems[i]["id"];
                                    timeout=timeout+800;
                                    setTimeout(function(){ 
                                        utils.api.cart.itemRemove(remove_hazmat_fee, (err, response) => {
                                            
                                        });
                                    },timeout);
                                }
                            }
                        }

                        if(i == physicalItems.length-1){
                            timeout=timeout+1500;
                            setTimeout(function(){ 
                                location.reload();
                            },timeout);
                        }
                    }

                    return cartJson[0].id;
                }).catch(function (error) {
                    console.log(error);
                }).then(function (cartId) {
                    
                });

                cartRemoveItem(itemId);
                // remove item from cart
                
            });
            event.preventDefault();
        });

        $('[data-item-edit]', this.$cartContent).on('click', event => {
            const itemId = $(event.currentTarget).data('itemEdit');

            event.preventDefault();
            // edit item in cart
            this.cartEditOptions(itemId);
        });
    }

    bindPromoCodeEvents() {
        const $couponContainer = $('.coupon-code');
        const $couponForm = $('.coupon-form');
        const $codeInput = $('[name="couponcode"]', $couponForm);

        $('.coupon-code-add').on('click', event => {
            event.preventDefault();

            $(event.currentTarget).hide();
            $couponContainer.show();
            $('.coupon-code-cancel').show();
            $codeInput.trigger('focus');
        });

        $('.coupon-code-cancel').on('click', event => {
            event.preventDefault();

            $couponContainer.hide();
            $('.coupon-code-cancel').hide();
            $('.coupon-code-add').show();
        });

        $couponForm.on('submit', event => {
            const code = $codeInput.val();

            event.preventDefault();

            // Empty code
            if (!code) {
                return swal({
                    text: $codeInput.data('error'),
                    type: 'error',
                });
            }

            utils.api.cart.applyCode(code, (err, response) => {
                if (response.data.status === 'success') {
                    this.refreshContent();
                } else {
                    swal({
                        text: response.data.errors.join('\n'),
                        type: 'error',
                    });
                }
            });
        });
    }

    bindGiftCertificateEvents() {
        const $certContainer = $('.gift-certificate-code');
        const $certForm = $('.cart-gift-certificate-form');
        const $certInput = $('[name="certcode"]', $certForm);

        $('.gift-certificate-add').on('click', event => {
            event.preventDefault();
            $(event.currentTarget).toggle();
            $certContainer.toggle();
            $('.gift-certificate-cancel').toggle();
        });

        $('.gift-certificate-cancel').on('click', event => {
            event.preventDefault();
            $certContainer.toggle();
            $('.gift-certificate-add').toggle();
            $('.gift-certificate-cancel').toggle();
        });

        $certForm.on('submit', event => {
            const code = $certInput.val();

            event.preventDefault();

            if (!giftCertCheck(code)) {
                return swal({
                    text: $certInput.data('error'),
                    type: 'error',
                });
            }

            utils.api.cart.applyGiftCertificate(code, (err, resp) => {
                if (resp.data.status === 'success') {
                    this.refreshContent();
                } else {
                    swal({
                        text: resp.data.errors.join('\n'),
                        type: 'error',
                    });
                }
            });
        });
    }

    bindGiftWrappingEvents() {
        const modal = defaultModal();

        $('[data-item-giftwrap]').on('click', event => {
            const itemId = $(event.currentTarget).data('itemGiftwrap');
            const options = {
                template: 'cart/modals/gift-wrapping-form',
            };

            event.preventDefault();

            modal.open();

            utils.api.cart.getItemGiftWrappingOptions(itemId, options, (err, response) => {
                modal.updateContent(response.content);

                this.bindGiftWrappingForm();
            });
        });
    }

    bindGiftWrappingForm() {
        $('.giftWrapping-select').on('change', event => {
            const $select = $(event.currentTarget);
            const id = $select.val();
            const index = $select.data('index');

            if (!id) {
                return;
            }

            const allowMessage = $select.find(`option[value=${id}]`).data('allowMessage');

            $(`.giftWrapping-image-${index}`).hide();
            $(`#giftWrapping-image-${index}-${id}`).show();

            if (allowMessage) {
                $(`#giftWrapping-message-${index}`).show();
            } else {
                $(`#giftWrapping-message-${index}`).hide();
            }
        });

        $('.giftWrapping-select').trigger('change');

        function toggleViews() {
            const value = $('input:radio[name ="giftwraptype"]:checked').val();
            const $singleForm = $('.giftWrapping-single');
            const $multiForm = $('.giftWrapping-multiple');

            if (value === 'same') {
                $singleForm.show();
                $multiForm.hide();
            } else {
                $singleForm.hide();
                $multiForm.show();
            }
        }

        $('[name="giftwraptype"]').on('click', toggleViews);

        toggleViews();
    }

    bindEvents() {
        this.bindCartEvents();
        this.bindPromoCodeEvents();
        this.bindGiftWrappingEvents();
        this.bindGiftCertificateEvents();

        // initiate shipping estimator module
        this.shippingEstimator = new ShippingEstimator($('[data-shipping-estimator]'));
    }
}
