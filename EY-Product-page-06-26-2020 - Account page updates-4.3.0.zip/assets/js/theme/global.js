import './global/jquery-migrate';
import './common/select-option-plugin';
import PageManager from './page-manager';
import quickSearch from './global/quick-search';
import currencySelector from './global/currency-selector';
import mobileMenuToggle from './global/mobile-menu-toggle';
import menu from './global/menu';
import foundation from './global/foundation';
import quickView from './global/quick-view';
import cartPreview from './global/cart-preview';
import privacyCookieNotification from './global/cookieNotification';
import maintenanceMode from './global/maintenanceMode';
import carousel from './common/carousel';
import loadingProgressBar from './global/loading-progress-bar';
import svgInjector from './global/svg-injector';
import objectFitImages from './global/object-fit-polyfill';
import utils from '@bigcommerce/stencil-utils';
import './global/eystudios/ey-pdp';

export default class Global extends PageManager {
    onReady() {
        cartPreview(this.context.secureBaseUrl, this.context.cartId);
        quickSearch();
        currencySelector();
        foundation($(document));
        quickView(this.context);
        carousel();
        menu();
        mobileMenuToggle();
        privacyCookieNotification();
        maintenanceMode(this.context.maintenanceMode);
        loadingProgressBar();
        svgInjector();
        objectFitImages();
    }
}

$(document).ready(function(){

    $(".close-top-banner").on("click",function(){
        $(".banners[data-banner-location=top]").remove();
        $("body").addClass("banner-removed");
    });
    $(window).resize(function() {
        
        if($(window).width() < 768){
            $(".footer-info-heading").not(".contact-us-heading").addClass("accordian");
            $(".footer-info-col.newsletter .form").addClass("accordian-child");
            //$(".footer-info-list .contact").addClass("accordian-child");
            $(".accordian-child").hide();
            $(".footer-info-list").not(".contact").hide();
        }else{
            $(".footer-info-heading").removeClass("accordian");
            $(".footer-info-heading").removeClass("open");
            //$(".footer-info-heading .accordian-child").show();
            $(".footer-info-list").show();
            $(".newsletter .form").show();
        }
    });
        if($(window).width() < 768){
            $(".footer-info-heading").not(".contact-us-heading").addClass("accordian");
            $(".footer-info-col.newsletter .form").addClass("accordian-child");
            $(".footer-info-col.newsletter .form").addClass("accordian-newsletter");
            //$(".footer-info-list .contact").addClass("accordian-child");
            $(".accordian-child").hide();
            $(".footer-info-list").not(".contact").hide();
            
        }else{
            $(".footer-info-heading").removeClass("accordian");
            $(".footer-info-heading").removeClass("open");
            $(".footer-info-heading .accordian-child").show();
            $(".footer-info-list").show();
            $(".newsletter .form").show();
        }
    
    $("body").on("click",".footer-info-heading.accordian",function(e){
        //$(".footer-info-heading.accordian").removeClass('open');
        if($(this).hasClass("open")){
            if($(this).parents(".footer-info-col").hasClass("newsletter")){
                $(".newsletter .form").hide();
            }
            $(this).removeClass("open");
            $(this).next().css('display','none');
        }else{
            if($(this).parents(".footer-info-col").hasClass("newsletter")){
                $(".newsletter .form").show();
            }
            $(this).addClass('open');
            $(this).next().css('display','block');
        }
        //$(".accordian-child").hide();
    });

    if($(".parent_product_name").length>0){
        $(".parent_product_name").val($(".product-view-configurable .productView-title").text());
        
        $(".add-on-product").each(function(){
            
            if($(this).hasClass("faa_form_id")==true){
                var productId=$(this).attr("id");
                utils.api.product.getById(productId, 
                { template: "products/json" },
                (err, resp) => {
                    var product_json=JSON.parse(resp);
                    var product_price=product_json.data.root.product.price.without_tax.formatted;
                    $(this).html('<option value="no">No Thanks</option><option value="yes">Yes (+'+product_price+')</option>');                    
                }); 
            }else{
                var productId=$(this).val();

                utils.api.product.getById(productId, 
                { template: "products/json" },
                (err, resp) => {
                    var product_json=JSON.parse(resp);
                    var product_price=product_json.data.root.product.price.without_tax.formatted;
                    $(".add-on-price_"+productId).text(product_price+" - ");
                });
            } 
        }); 

    }

    if($(".parent_product_part").length>0){
        //$(".parent_product_part").val($(".product-part-number").val());        
        $(".parent_product_part").val($(".product-part-number").text());
    }

    $(".part-number-sku").each(function(){
        var part_class=$(this).text();
        part_class=part_class.trim();
        
        if($("."+part_class).find(".part-class").length<=0){
           $("."+part_class).append("<span class='part-class'>Part #: "+part_class+"</span>");
        }
    });

    $("body .form-input--incrementTotal").on("focusout",function(){
        $(".parent_product_qty").val($(this).val());
    });

    $('.hazmat_fee_id:checkbox[readonly]').click(function(){
        return false;
    });

    $(".terms .title").click(function(){
        if($(this).parent("li").hasClass("active")==true){
            $(this).parent("li").removeClass("active");
        }else{
            $(this).parent("li").addClass("active");
        }    
    });
    
    $('.required-checkbox').on('click', function(ev){
        ev.preventDefault();
    });
});


