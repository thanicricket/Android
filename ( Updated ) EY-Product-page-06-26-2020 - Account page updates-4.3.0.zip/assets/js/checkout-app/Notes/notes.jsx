import React, { Fragment } from 'react';
import TextInput from '../components/TextInput/text-input';
import Section from '../components/Section/section';

export default class Notes extends React.PureComponent {
    constructor(props) {
        super(props);

        this.state = {
            customerMessage: '',
        };
    }

    componentDidMount() {

        let customerMessage = this.props.customerMessage;
        if (customerMessage) {
            this.setState({ customerMessage });
        }
    }

    componentDidUpdate() {
        this.props.onChange(this.state);
    }

    render() {
        return (
            <Section
                header={ 'ORDER COMMENTS' }
                body={
                   <Fragment>
                        <TextInput
                            id={ 'guestEmail' }
                            label={ 'CustomerMessage' }
                            value={ this.state.customerMessage }
                            optional={ true }
                            onChange={ ({ target }) => this.setState({ customerMessage: target.value }) } />
                    </Fragment>
                } />
        );
    }
}
