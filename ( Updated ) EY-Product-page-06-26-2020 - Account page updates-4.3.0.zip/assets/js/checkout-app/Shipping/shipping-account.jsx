import React, { Fragment } from 'react';
import { formatMoney } from 'accounting';
import { createCheckoutService } from '@bigcommerce/checkout-sdk';
import EmptyState from './EmptyState/empty-state';
import RadioContainer from '../components/RadioContainer/radio-container';
import RadioInput from '../components/RadioInput/radio-input';
import TextInput from '../components/TextInput/text-input';
import Section from '../components/Section/section';


export default class ShippingAccounts extends React.PureComponent {
    constructor(props) {
        super(props);
            
        this.state = {
            shippingACno:""
        };
       
    }

    componentDidMount() {

        let shippingACno = this.props.shippingACno;
        if (shippingACno) {
            this.setState({ shippingACno });
        }
    }

    
    render() {
        return (
            <Section    
                header={ '' }
                body={
                   <Fragment>
                        <Fragment>
                            <RadioContainer
                                body={
                                    <Fragment>
                                    <div className="shipping-account-radio">
                                        <RadioInput
                                            id={ 'shipemnt-account-enable' }
                                            name={ 'shipemnt-account-enable' }
                                            label={ 'Ship Collect?' }
                                            optional={ true }
                                            onChange={ ({ target }) => this.props.onshippingACRadioChange() }
                                            selected= { this.state.shipping_selected }
                                            className = { "shipemnt-account-enable" } 
                                        />
                                    </div>
                                    <div className="shipping-account-input">
                                        <TextInput
                                            id={ 'shippingAccountNO' }
                                            label={ 'ENTER ACCOUNT NUMBER' }
                                            value={ this.state.shippingACno }
                                            optional={ true }
                                            
                                            onChange={ ({ target }) => this.props.onshippingACNumberChange(this.setState({ shippingACno: target.value })) }
                                        />
                                    </div>
                                    <div className="Shippment-content">
                                        This option requires an additional $5 processing fee. 
                                    </div>
                                    </Fragment>
                                } />    
                         </Fragment>
                    </Fragment>
                } />
        );
    }

    
}

