import React, { Fragment } from 'react';
import { formatMoney } from 'accounting';
import { createCheckoutService } from '@bigcommerce/checkout-sdk';
import EmptyState from './EmptyState/empty-state';
import RadioContainer from '../components/RadioContainer/radio-container';
import RadioInput from '../components/RadioInput/radio-input';
import TextInput from '../components/TextInput/text-input';
import Section from '../components/Section/section';


export default class ShippingAccounts extends React.PureComponent {
    constructor(props) {
        super(props);
    }

    
    render() {
        return (
            <Section    
                header={ 'Use Your Shipping Account:' }
                body={
                   <Fragment>
                        <Fragment>
                            <RadioContainer
                                body={
                                    <Fragment>
                                    <div className="store-shipping-button orderShipment">
                                        <RadioInput
                                            id={ 'bill-shipping-to-order' }
                                            name={ 'customerShippingAccount' }
                                            label={ 'Bill shipping to your order' }
                                            optional={ true }
                                            onChange={ ({ target }) => this.props.shippingRadioChange('1') }
                                            selected= { true }
                                            className = { "choose_order_methods" } 

                                             />
                                    </div>
                                    </Fragment>
                                } />
                         </Fragment>
                    </Fragment>
                } />
        );
    }

    
}

