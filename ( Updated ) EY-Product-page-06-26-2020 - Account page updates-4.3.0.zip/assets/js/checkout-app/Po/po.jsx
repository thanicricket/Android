import React, { Fragment } from 'react';
import TextInput from '../components/TextInput/text-input';
import Section from '../components/Section/section';

export default class Po extends React.PureComponent {
    constructor(props) {
        super(props);
        
        console.log(this.props);

        this.state = {
            POValue: '',
        };
    }

    componentDidMount() {

        let POValue = this.props.POValue;
        if (POValue) {
            this.setState({ POValue });
        }
    }

    componentDidUpdate() {
        this.props.onChange(this.state);
    }
    
    render() {
        return (
            <Section
                header={ '' }
                body={
                   <Fragment>
                        <TextInput
                            id={ 'pofield' }
                            label={ 'PO Number' }
                            value={ this.state.POValue }
                            optional={ true }
                            onChange={ ({ target }) => this.setState({ POValue: target.value }) } 
                            onChange={ ({ target }) => this.props.onChangePONumber(this.setState({ POValue: target.value })) } />
                    </Fragment>
                } />
        );
    }
}
