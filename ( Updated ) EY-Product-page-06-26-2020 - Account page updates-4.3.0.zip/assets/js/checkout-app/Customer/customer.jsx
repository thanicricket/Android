import React, { Fragment } from 'react';
import Button from '../components/Button/button';
import EmailInput from '../components/EmailInput/email-input';
import Section from '../components/Section/section';
import styles from './customer.scss';
import validator from 'validator';

export default class Customer extends React.PureComponent {
    constructor(props) {
        super(props);

        this.state = {
            email: '',
        };
	
	this.change_sign_out = this.change_sign_out.bind(this);
        this.handleGuestValidation = this.handleGuestValidation.bind(this);
    }
	
    componentWillMount() {
        //.log('willmount');
       // //console.log(this.props.edit_button_cutomer);
        // login user when load checkout page directly move to shipping section
        if(!this.props.customer.isGuest && this.props.data_show){
            this.props.onChange_toggle_customer();
        }
    }
    
    componentDidMount() {
        let email = this.props.customer.isGuest ?
            this.props.customer.email :
            this.props.billingAddress.email;

        if (email && email !== this.state.email) {
            this.setState({ email });
        }
    }

    componentDidUpdate() {
        this.props.onChange(this.state);
    }

    change_sign_out(){
        ////console.log("onChangeSign_out");
       // //console.log(this.props);
        //When user click signout button, trigger props to sent data for hidden all other components
        this.props.onChangeSign_out();
        this.props.onClick();
    }

    handleGuestValidation(e){
        event.preventDefault();
	this.props.onChange_toggle_customer();
        const guest_customer_email = e.target.guestEmail.value.trim();
        //console.log(guest_customer_email);
        const is_email_valid = guest_customer_email !='' ? validator.isEmail(guest_customer_email) : 'Email is required' ;
        //console.log(is_email_valid);
        this.setState ( () => ({guest_email_error : typeof is_email_valid === "boolean" ? is_email_valid ? '' : 'Email address must be valid' : 'Email address is required'}));
        if(is_email_valid == true ){
            this.props.onChange_toggle_customer();
            this.setState({ continue_data: this.state.email});
        }
    }

    render() {
        return (
            <Section
                header={ 'Customer Information' }
		data_show={this.props.data_show}
                edit_data = {this.props.customer.isGuest}
                customer_email = { this.props.customer.email }
                customer_details = {this.state.continue_data}
                edit_checkout_section = {this.props.edit_customer_section}
                edit_button_show = {this.props.edit_button_cutomer}
                sign_out_data = { this.props.isSigningOut ? `Signing out...` : 'Sign Out' }
                onChange = {()=> this.change_sign_out()}
                body={
                    <Fragment>
                        { this.props.customer.isGuest &&
                            <Fragment>
                                <EmailInput
                                    id={ 'guestEmail' }
                                    label={ 'Email' }
                                    value={ this.state.email }
                                    onChange={ ({ target }) => this.setState({ email: target.value }) } />

                                <div className={ styles.actionContainer }>
                                    Already have an account? <a onClick={ this.props.onSignIn }>Sign in now</a> <span>|</span> <a href="">Create an account</a>
                                </div>
                                <p className="remember-login">
                                    <a href="">Tax Exempt?</a> Remember to sign in or to create your Account 
                                </p>
				<div className="form-actions customerEmail-action">
				    <button onClick={ this.handleGuestValidation } id="checkout-customer-continue" className="button customerEmail-button button--primary optimizedCheckout-buttonPrimary" data-test="customer-continue-as-guest-button" type="submit">Continue as guest</button>
				</div>
                            </Fragment>
                        }

                        { !this.props.customer.isGuest &&
                            <div className={ styles.customerContainer }>
                                <div className={ styles.customerLabel }>
                                    { this.props.customer.email }
                                </div>

                                <Button
                                    label={ this.props.isSigningOut ? `Signing out...` : 'Sign Out' }
                                    onClick={ this.props.onClick } />
                            </div>
                        }
                    </Fragment>
                } />
        );
    }
}
